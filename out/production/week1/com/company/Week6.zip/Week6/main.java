package com.company.Week6;

import java.util.Iterator;

public class main {
    public static void main(String []args) {

//        DoubleLinkedList<String> doubleLinkedList = new DoubleLinkedList<>();
//
//        doubleLinkedList.add("0", true);
//        doubleLinkedList.add("1",false);
//        doubleLinkedList.add("2",true);
//        doubleLinkedList.add("3",false);
//        doubleLinkedList.add("4",true);
//        doubleLinkedList.add("5",false);
//
//
//        DoubleLInkedIterator<String> list = (DoubleLInkedIterator<String>)doubleLinkedList.backwardIterator();
//
//        while(list.hasNext()){
//            System.out.println(list.next());
//        }
        int []arr = {0,2,3,1,4,2,3,1,2,3};
        int n = arr.length;
        System.out.println(n/2);
    }
}
