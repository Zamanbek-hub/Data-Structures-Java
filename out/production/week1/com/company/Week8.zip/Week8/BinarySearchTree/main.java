package com.company.Week8.BinarySearchTree;

public class main {
    public static void  main(String []args){
        BinarySearchTree<Integer> Tree = new BinarySearchTree<>();
        Tree.insert(45);
        Tree.insert(17);
        Tree.insert(18);
        Tree.insert(16);
        Tree.insert(19);
        Tree.insert(20);
        Tree.insert(70);
        Tree.insert(60);
        Tree.insert(85);
//        System.out.println("Root = " + Tree.getRoot().getData());
//        Tree.delete(5);
        Tree.postOrder();
//        System.out.println("Yeaaaaaaaa");
//        System.out.println("Root = " + Tree.getRoot().getData());
////        System.out.println(Tree.find(5).getData());
//        System.out.println(Tree.largest());
    }
}
