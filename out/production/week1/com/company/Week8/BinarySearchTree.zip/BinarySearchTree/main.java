package com.company.Week8.BinarySearchTree;

public class main {
    public static void  main(String []args){
        BinarySearchTree<Integer> Tree = new BinarySearchTree<>();
        Tree.insert(3);
        Tree.insert(5);
        Tree.insert(4);
        Tree.insert(6);
        Tree.insert(8);
        Tree.insert(7);
        Tree.insert(2);
        Tree.insert(9);
        Tree.insert(1);
        System.out.println("Root = " + Tree.getRoot().getData());
        Tree.delete(5);
        Tree.inorder();
        System.out.println("Yeaaaaaaaa");
        System.out.println("Root = " + Tree.getRoot().getData());
//        System.out.println(Tree.find(5).getData());
        System.out.println(Tree.largest());
    }
}
